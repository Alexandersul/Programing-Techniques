#include <string.h>
#include <stdio.h> 
#define FN_SORTARE(TIP)
{
TIP sortare(int *v,int n)
{
int aux;
for(int i=0;i<n;i++)
for(int j=i+1;j<n;j++)
if(a[i]>a[j])
{
aux=a[i];
a[i]=a[j];
a[j]=aux;
}
}
}
FN_SORTARE(int);
FN_SORTARE(unsigned);
FN_SORTARE(float);
FN_SORTARE(char);
int main(* char tip)
{
FN_SORTARE(tip);
}